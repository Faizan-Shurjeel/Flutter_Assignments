package com.example.fcm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

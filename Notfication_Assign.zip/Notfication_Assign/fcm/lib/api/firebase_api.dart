// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:logging/logging.dart';

// class FirebaseApi {
// /*Steps:

//   Create INstance of Firebase Messaging
//   Function to initialize Notifications
//   Function to handle received messages
//   Function to initialize foreground & background settings
// */
//   final _firebaseMessaging = FirebaseMessaging.instance;
//   Future<void> initNotifications() async {
//     await _firebaseMessaging.requestPermission();

//     //Request for permission from user (prompt)
//     //FEtch FCM Token for this device
//     final fcmToken = await _firebaseMessaging.getToken();
//     //Print the token (usually we send this to server)
//     if (fcmToken != null) {
//       // Use a logging framework instead of print
//       // For example, using the 'logging' package
//       final log = Logger('FirebaseApi');
//       log.info('Token: $fcmToken');
//     } else {
//       print('Failed to get FCM token');
//     }
//   }
// }

/* Here Foreground And Background Notifications are handled
   Foreground Notifications are handled by the onMessage stream
   Background Notifications are handled by the onBackgroundMessage stream
   The _showNotification function is used to display the notification
   The _firebaseMessagingBackgroundHandler function is used to handle background messages
*/

// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:logging/logging.dart';

// class FirebaseApi {
//   final _firebaseMessaging = FirebaseMessaging.instance;
//   final _log = Logger('FirebaseApi');
//   final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
//       FlutterLocalNotificationsPlugin();

//   Future<void> initNotifications() async {
//     await _firebaseMessaging.requestPermission();

//     // Fetch FCM Token for this device
//     final fcmToken = await _firebaseMessaging.getToken();
//     if (fcmToken != null) {
//       _log.info('Token: $fcmToken');
//     } else {
//       _log.warning('Failed to get FCM token');
//     }

//     // Initialize local notifications
//     const AndroidInitializationSettings initializationSettingsAndroid =
//         AndroidInitializationSettings('@mipmap/ic_launcher');
//     const InitializationSettings initializationSettings =
//         InitializationSettings(android: initializationSettingsAndroid);
//     await _flutterLocalNotificationsPlugin.initialize(initializationSettings);

//     // Handle foreground messages
//     FirebaseMessaging.onMessage.listen((RemoteMessage message) {
//       _log.info('Received a message while in the foreground!');
//       _log.info('Message data: ${message.data}');

//       if (message.notification != null) {
//         _log.info(
//             'Message also contained a notification: ${message.notification}');
//         _showNotification(message);
//       }
//     });

//     // Handle background messages
//     FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
//   }

//   Future<void> _showNotification(RemoteMessage message) async {
//     const AndroidNotificationDetails androidPlatformChannelSpecifics =
//         AndroidNotificationDetails(
//       'your_channel_id',
//       'your_channel_name',
//       importance: Importance.max,
//       priority: Priority.high,
//       showWhen: false,
//     );
//     const NotificationDetails platformChannelSpecifics =
//         NotificationDetails(android: androidPlatformChannelSpecifics);
//     await _flutterLocalNotificationsPlugin.show(
//       0,
//       message.notification?.title,
//       message.notification?.body,
//       platformChannelSpecifics,
//       payload: 'item x',
//     );
//   }
// }

// Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
//   Logger('FirebaseApi')
//       .info('Handling a background message: ${message.messageId}');
// }

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:logging/logging.dart';
import 'package:firebase_core/firebase_core.dart';

class FirebaseApi {
  final _firebaseMessaging = FirebaseMessaging.instance;
  final _log = Logger('FirebaseApi');
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> initNotifications() async {
    await _firebaseMessaging.requestPermission();

    // Fetch FCM Token for this device
    final fcmToken = await _firebaseMessaging.getToken();
    if (fcmToken != null) {
      _log.info('Token: $fcmToken');
    } else {
      _log.warning('Failed to get FCM token');
    }

    // Initialize local notifications
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);
    await _flutterLocalNotificationsPlugin.initialize(initializationSettings);

    // Handle foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      _log.info('Received a message while in the foreground!');
      _log.info('Message data: ${message.data}');

      if (message.notification != null) {
        _log.info(
            'Message also contained a notification: ${message.notification}');
        _showNotification(message);
      }
    });

    // Handle background messages
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  }

  Future<void> _showNotification(RemoteMessage message) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'your_channel_id',
      'your_channel_name',
      importance: Importance.max,
      priority: Priority.high,
      showWhen: false,
    );
    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);
    await _flutterLocalNotificationsPlugin.show(
      0,
      message.notification?.title,
      message.notification?.body,
      platformChannelSpecifics,
      payload: 'item x',
    );
  }
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  Logger('FirebaseApi')
      .info('Handling a background message: ${message.messageId}');
  _showNotification(message);
}

void _showNotification(RemoteMessage message) async {
  const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
    'channel_id',
    'channel_name',
    channelDescription: 'channel_description',
    importance: Importance.max,
    priority: Priority.high,
    ticker: 'ticker',
  );

  const NotificationDetails notificationDetails =
      NotificationDetails(android: androidDetails);

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  await flutterLocalNotificationsPlugin.show(
    message.hashCode,
    message.notification?.title,
    message.notification?.body,
    notificationDetails,
  );
}

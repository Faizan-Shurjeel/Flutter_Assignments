/*
Changes Made to:
1. main.dart
2. firebase_options.dart
3. home_page.dart
4. firebase_api.dart
5. pubspec.yaml
6. android/app/build.gradle (for FCM) (Don't remember)
7. android/app/src/main/AndroidManifest.xml (for FCM) 
*/

import 'package:fcm/api/firebase_api.dart';
import 'package:fcm/firebase_options.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'pages/home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await FirebaseApi().initNotifications();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FCM',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: const MyHomePage(title: 'FCM'),
    );
  }
}
